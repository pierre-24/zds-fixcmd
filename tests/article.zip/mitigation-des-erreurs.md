Il existe différentes techniques pour mitiger les erreurs.

# Erreur de position et vitesse initiale et initialisation

Pour mitiger l’erreur de position et de vitesse initiales, il est possible d’effectuer l’initialisation dans des conditions précises connues. Par exemple, pour un véhicule terrestre, il s’agirait de faire une mesure à l’arrêt (vitesse nulle) en un point précisément mesuré (erreur de position faible).

Ce n’est pas toujours possible, si on ne peut pas se mettre à l’arrêt ni savoir précisément où l’on est. C’est le cas notamment pour un bateau en pleine mer : le courant et le vent empêchent de mesurer la véritable vitesse, c’est-à-dire la vitesse par rapport au fond et la précision de la position initiale est limitée par les moyens du bord.

# Erreur d’intégration et puissance du calculateur

Nous avons vu dans la partie précédente que si on mettait à jour l’estimation trop lentement, l’erreur de position s’accumulait. Pour limiter ce type d’erreur, il suffit alors de procéder plus vite. 

La performance du calculateur peut devenir bloquante. D’une part, les contraintes de coûts limitent la puissance des calculateurs dans les applications grand public (dans un téléphone par exemple) ; d’autres part, plus les accélérations maximales du véhicule sont importantes et le positionnement nécessaire précis, plus la mise à jour doit se faire vite (dans un avion de chasse par exemple), ce qui peut devenir limitant pour du calcul en temps réel.

# Erreur de mesure, filtrage et fusion de capteurs

Les erreurs de mesure sont vraiment les plus gênantes, car elles sont à la longue la principale cause de dérive. Pour les applications exigeantes, les ingénieurs travaillent sur des capteurs très précis et robustes qui limitent fortement les erreurs (par exemple basés sur de l’interférométrie laser). 

Mais même les meilleurs capteurs ne peuvent éviter totalement la dérive, il suffit d’attendre suffisamment longtemps pour que l’erreur devienne arbitrairement grande. C’est pourquoi on a recours à des techniques où l’on mélange l’information de différents capteurs.

Un cas typique est de mélanger l’estimation inertielle avec une mesure de position par satellite, comme le GPS. Cela permet d’éliminer la dérive, tout en ayant une précision supérieure à celle de chaque capteur pris séparément. La figure montre un exemple de telle mélange ; il utilise une technique simpliste mais illustre bien le principe : l’estimation combinée est meilleure que le GPS seul et sans dérive.

![Fusion de l’information de navigation inertielle et GPS.](/media/galleries/4488/37ce8231-82cd-4384-bd7d-fac7bea45fba.png)

Une technique usuelle non simpliste est le *filtrage de Kalman*. Cette technique permet de réaliser un filtre qui mélange de manière optimale (selon certains critères) les informations obtenues par navigation inertielle et par mesure de position, en prenant en compte les erreurs du modèle physique et les erreurs de mesure.