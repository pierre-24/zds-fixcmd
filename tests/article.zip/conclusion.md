Et voilà pour cette introduction ! Vous avez vu dans le principe général de la navigation inertielle. Si vous souhaitez découvrir ce domaine plus en détail,  sachez qu’il y a énormément de spécificités pratiques à découvrir, telles que la prise en compte de la gravité terrestre, de la rotondité de la Terre et toutes les autres subtilités nécessaires à la mise en pratique industrielle de la navigation inertielle.

# Références

* Article [Navigation inertielle](https://fr.wikipedia.org/wiki/Navigation_inertielle) sur Wikipédia,
* Article [Centrale à inertie](https://fr.wikipedia.org/wiki/Centrale_à_inertie) sur Wikipédia,
* Article [Calcul numérique d’une intégrale](https://fr.wikipedia.org/wiki/Calcul_numérique_d'une_intégrale) sur Wikipédia,
* Article [*Kalman Filtering*](https://en.wikipedia.org/wiki/Kalman_filter) sur Wikipedia (en anglais),
* Notes du cours [Introduction au filtre de Kalman](http://oatao.univ-toulouse.fr/2248/1/Alazard_2248.pdf).

# Remerciements

Merci à [Dwayn](https://zestedesavoir.com/membres/voir/Dwayn/) pour les relectures en bêta et à [adri1](https://zestedesavoir.com/membres/voir/adri1/) pour la validation.

---
*Illustration de la miniature : Carte du monde faite à partir des données de Natural Earth (projection: planisphère Hölzels centrée 10° est), par [Ktrinko](https://commons.wikimedia.org/wiki/User:Ktrinko), sous licence [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0).*