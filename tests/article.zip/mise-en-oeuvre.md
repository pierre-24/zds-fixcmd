Les lois physiques vues ci-avant peuvent être simulées en temps réel par un calculateur, en utilisant des techniques d’intégration numérique.

Nous utilisons ici la [méthode d’Euler](https://zestedesavoir.com/tutoriels/528/simulez-des-systemes-physiques-avec-la-methode-deuler/), qui est certainement la technique la plus simple. D’autres approches plus raffinées existent, mais elles ne sont pas utiles pour notre article.

Le cœur de la méthode d’Euler, dans notre cas, consiste à approximer le taux de variation entre deux instants suffisamment proches par la dérivée. 

![Approximation du taux d’accroissement par la méthode d’Euler.](/media/galleries/4488/6b13088d-6315-4065-87ca-7e2755b54bd9.png)

En appliquant cette approximation dans notre cas, on déduit deux récurrences : une pour mettre à jour la vitesse, et une pour mettre à jour la position. Notez qu’on travaille toujours sur une seule dimension par simplification, mais qu’on pourrait aisément généraliser à trois dimensions.

Le calcul se déroule de la manière suivante[^une_dim]. On part d’une estimation de position initiale $p_0$ et de vitesse initiale $v_0$. Ensuite, à chaque instant $t_k$ où l’on souhaite estimer la position, on commence par mettre à jour l’estimation de vitesse :

[^une_dim]: On travaille toujours sur une seule dimension, comme dans la première section, mais les calculs pour les autres dimensions sont identiques.

$$ v_k = v_{k-1} + (t_k - t_{k-1}) a_{k} $$

Après, on met à jour l’estimation de position :

$$ p_k = p_{k-1} + (t_k - t_{k-1}) v_k $$

Et on recommence à un nouvel instant en partant de l’estimation précédente.

Pour que la méthode d’Euler estime suffisamment bien la véritable intégrale, il faut que les instants $t_k$ soient suffisamment proches les uns des autres, c’est-à-dire que la fréquence de mise à jour soit suffisamment élevée. 

Reprenons notre voiture de sport de la section précédente et estimons sa position  avec les calculs vus ci-avant. Le résultat est montré dans la figure ci-dessous. La réalité physique et l’estimation sont presque indiscernables ! 

![Estimation de la position d’une voiture de sport par intégration numérique.](/media/galleries/4488/bc05c975-7740-4e59-80a9-0bb731adc9af.png)