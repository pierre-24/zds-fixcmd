De nos jours, il est facile de savoir où l’on est. Grâce au GPS ou à des systèmes concurrents, connaître précisément sa position est devenu un jeu d’enfant. Les récepteurs GPS sont d’ailleurs partout, que ce soit dans les téléphones, les voitures, les avions, ou encore les bateaux.

Pourtant, le GPS ne répond pas à tous les besoins. Pour certaines applications, il est trop cher, trop peu précis, ou tout simplement impossible à mettre en œuvre. Par exemple, pour les sous-marins en plongée, il n’est pas possible de capter les signaux du GPS. Sur un champ de bataille, le positionnement doit rester précis même en cas de brouillage. Sur les systèmes grand public, les contraintes de coût limitent encore la précision.

Quand le GPS seul n’est pas une option viable, on recourt souvent à la **navigation inertielle**. Cette technique permet d’estimer le déplacement d’un objet avec seulement un capteur d’accélération et un chronomètre. Cet article en présente le principe de fonctionnement.

*[GPS]: Global Positioning System