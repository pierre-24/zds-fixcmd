La section précédente fait une démonstration de la navigation inertielle dans un cas idéalisé. En pratique, différents phénomènes introduisent des erreurs dans le processus d’estimation. 

# Erreur sur les conditions initiales

Les conditions initiales, position et vitesse, sont souvent issues de mesures, entachées d’erreur plus ou moins importantes. 

Par exemple, en mer, un bateau pourrait se repérer en utilisant les étoiles, mais les instruments de mesure n’étant pas parfaitement précis, la position ne serait connue que de manière approximative. 

De même, toutes sortes d’instruments permettent de mesurer la vitesse avec une erreur variable.

L’erreur de position initiale créée un décalage entre l’estimation et la réalité, qui va perdurer indéfiniment. L’erreur de vitesse initiale, quant à elle, fait dériver l’estimation, en introduisant un décalage qui croît proportionnellement avec le temps, rendant à terme l’estimation inutile. 

![Effet d'une erreur de position initiale.](/media/galleries/4488/d4b49175-3fcc-4220-9c4e-54c0b7d1227b.png)

![Effet d'une erreur de vitesse initiale.](/media/galleries/4488/5cfe4721-b5d1-4f9f-8a58-194145429af6.png)

# Erreur d’intégration numérique

La méthode d’intégration numérique introduit des erreurs qui grandissent à mesure que la fréquence de mise à jour diminue. Ce phénomène s’explique par le fait que l’approximation du taux d'accroissement devient de moins en moins bonne quand la fréquence de la mise à jour diminue. 

En pratique, les calculateurs modernes permettent une précision respectable. Cependant, si on attend suffisamment longtemps, cette erreur finira toujours par se manifester sensiblement.

L’exemple ci-dessous reprend le cas de la voiture de sport. Cette fois-ci, la fréquence de mise à jour est beaucoup plus faible, et crée des erreurs qui s’accumulent au cours du temps. Pour que le phénomène soit bien visible, la fréquence de mise à jour est choisie volontairement très basse. 

![Erreur d’intégration numérique.](/media/galleries/4488/48e9f00b-1366-4021-8ab7-95f321431b7f.png)

# Erreur de mesure d’accélération

L’erreur la plus gênante en pratique est sans doute celle sur la mesure d’accélération. 

Les capteurs d’accélération présentent différents types d’erreurs liés à la constitution et à la chaîne de traitement du signal. On peut notamment citer le biais, le bruit de mesure, ou les non-linéarités.

Bien qu’on puisse les limiter, ces erreurs sont inévitables et entraînent une dérive à mesure que l’estimation prend en compte le bruit comme s’il s’agissait d’une véritable mesure. 

L’exemple ci-dessous montre comment la dérive affecte l’estimateur de position de notre voiture. La voiture est immobile, mais un bruit entraîne la dérive de l’estimateur, que j’aime appeler le « voyage immobile ». :-)

![Dérive due aux erreurs sur la mesure d’accélération.](/media/galleries/4488/dcbbf079-4e22-41cd-9dea-c409ae8a0085.png)

Il existe encore d’autres erreurs spécifiques à certaines applications, qui ne seront pas traitées dans cet article.