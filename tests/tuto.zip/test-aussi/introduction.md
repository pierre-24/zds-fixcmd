Avec une commande!

$$
\newcommand\testcmd[1]{\textbf{#1}}
$$