Avec une commande différente

$\newcommand\bin{\mathcal}$