C'est $\bin 1$ ou $\bin 0$ ?

Devrait être $\mathcal 1$ ou $\mathcal 0$